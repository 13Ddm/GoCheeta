package com.booking;

public class Booking {

}
